﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace WindowsFormsApp3
{
    public partial class Login : Form
    {

        public Login()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            String usertexBox = userTextBox.Text.Trim();
            String pwdtextBox = pwdTextBox.Text.Trim();
            try 
            {
                SchoolSQLConnection.SqlConnection.Open();
                String selectUserSql = "select username,password from users";
                SqlCommand sqlCommand = new SqlCommand();
                sqlCommand.Connection = SchoolSQLConnection.SqlConnection;
                sqlCommand.CommandText = selectUserSql;
                SqlDataReader sqlDataReader = sqlCommand.ExecuteReader();
                Boolean loginType = false;
                if (sqlDataReader.HasRows) 
                {
                    while (sqlDataReader.Read()) 
                    {
                        Object[] usersList = new Object[sqlDataReader.FieldCount];
                        sqlDataReader.GetValues(usersList);
                        if (usersList[0].ToString().Trim().Equals(usertexBox) &&
                            usersList[1].ToString().Trim().Equals(pwdtextBox))
                        {
                            loginType = true;
                        }
                    }
                }
                if (loginType)
                {
                    this.Hide();
                    SchoolSQLConnection.SqlConnection.Close();
                    new ShowStudents().Show();
                }
                else 
                {
                    MessageBox.Show("您输入的用户名与密码有误，请重新输入");
                }
            }
            catch(Exception ex) 
            {
                MessageBox.Show(ex.Message.ToString());
            }
            finally 
            {
                SchoolSQLConnection.SqlConnection.Close();
            }
        }

        private void Login_Load(object sender, EventArgs e)
        {
            SchoolSQLConnection.loginFrom =  this;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
