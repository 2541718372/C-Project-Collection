﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace WindowsFormsApp3
{
    public partial class ShowStudents : Form
    {
        /*SqlConnection SqlConnection = new SqlConnection("" +
            "Server=.;user=sa;pwd=123456;database=school");*/
        public ShowStudents()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            ListViewItem listViewItem = new ListViewItem();
            try 
            { 
                SchoolSQLConnection.SqlConnection.Open();
                String selectSqlStr = "select * from student";
                SqlCommand sqlCommand = new SqlCommand();
                sqlCommand.Connection = SchoolSQLConnection.SqlConnection;
                sqlCommand.CommandText = selectSqlStr;

                SqlDataReader sqlDataReader = sqlCommand.ExecuteReader();

                if (sqlDataReader.HasRows) 
                {
                    while (sqlDataReader.Read()) 
                    {
                        Object[] studentMeg = new Object[sqlDataReader.FieldCount];
                        sqlDataReader.GetValues(studentMeg);
                        //通过listview控件中的Items属性的Add方法代表我要向当前
                        //listView控件添加一项（条）数据
                        //在添加一项（条）数据的时候需要传递一个序号
                        listViewItem = listView1.Items.Add(studentMeg[0].ToString().Trim());
                        for (int i = 1; i < studentMeg.Length; i++) 
                        {
                            listViewItem.SubItems.Add(studentMeg[i].ToString().Trim());
                        }
                    }
                }
            }
            catch (Exception ex) 
            {
                MessageBox.Show(ex.Message.ToString());
            }
            finally 
            {
                SchoolSQLConnection.SqlConnection.Close();
            }
        }

        private void ShowStudents_FormClosed(object sender, FormClosedEventArgs e)
        {
            SchoolSQLConnection.loginFrom.Show();
        }
    }
}
