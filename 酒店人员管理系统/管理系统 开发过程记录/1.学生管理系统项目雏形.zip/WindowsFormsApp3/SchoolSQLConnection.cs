﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;

namespace WindowsFormsApp3
{
    public static class SchoolSQLConnection
    {
        public static SqlConnection SqlConnection = new SqlConnection("" +
            "Server=.;user=sa;pwd=123456;database=school");
        public static Login loginFrom;
    }
}
